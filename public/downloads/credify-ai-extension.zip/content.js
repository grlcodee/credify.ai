// This content script allows the extension to interact with web pages
// Currently minimal - can be expanded for future features like highlighting results

console.log('Credify AI extension loaded on', document.URL);

// Future: Add keyboard shortcuts, auto-detection, etc.
